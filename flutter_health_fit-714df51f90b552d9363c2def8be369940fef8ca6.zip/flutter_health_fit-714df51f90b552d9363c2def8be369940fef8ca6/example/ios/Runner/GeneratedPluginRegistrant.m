//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <flutter_health_fit/FlutterHealthFitPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterHealthFitPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterHealthFitPlugin"]];
}

@end
