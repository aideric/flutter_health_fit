#import <Flutter/Flutter.h>

@interface FlutterHealthFitPlugin : NSObject<FlutterPlugin>
@end
