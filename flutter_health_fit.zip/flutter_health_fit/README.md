# flutter_health_fit

A flutter plugin for using Apple HealthKit and Google Fit.

## Getting Started
* Add to pubspec.yaml: `flutter_health_fit`.
* Open your iOS Xcode project (Runner.xcworkspace)
* Capabilities: Enable HealthKit

* Open the `info.plist`
* Add: NSHealthUpdateUsageDescription, NSHealthShareUsageDescription.

* For android user
* https://developers.google.com/fit/android/get-api-key :D
 
