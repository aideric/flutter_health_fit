# flutter_health_fit_example

Demonstrates how to use the flutter_health_fit plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
